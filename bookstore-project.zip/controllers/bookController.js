const axios = require('axios');

const books = require('../books.json');

exports.getAllBooks = (req, res) => res.json(books);

exports.getBookByISBN = (req, res) => {
  const book = books.find(b => b.isbn === req.params.isbn);
  res.json(book || {});
};

exports.getBooksByAuthor = (req, res) => {
  const list = books.filter(b => b.author.toLowerCase().includes(req.params.author.toLowerCase()));
  res.json(list);
};

exports.getBooksByTitle = (req, res) => {
  const list = books.filter(b => b.title.toLowerCase().includes(req.params.title.toLowerCase()));
  res.json(list);
};

exports.getBookReview = (req, res) => {
  const book = books.find(b => b.isbn === req.params.isbn);
  res.json(book?.reviews || {});
};