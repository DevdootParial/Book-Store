const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

let users = [];
let reviews = {};

exports.register = (req, res) => {
  const { username, password } = req.body;
  const hashedPassword = bcrypt.hashSync(password, 8);
  users.push({ username, password: hashedPassword });
  res.json({ message: 'User registered' });
};

exports.login = (req, res) => {
  const { username, password } = req.body;
  const user = users.find(u => u.username === username);
  if (!user || !bcrypt.compareSync(password, user.password)) return res.status(401).send('Unauthorized');
  const token = jwt.sign({ username }, 'secret', { expiresIn: 86400 });
  res.json({ token });
};

exports.addOrUpdateReview = (req, res) => {
  const { isbn, review } = req.body;
  if (!reviews[isbn]) reviews[isbn] = [];
  reviews[isbn] = reviews[isbn].filter(r => r.username !== req.user);
  reviews[isbn].push({ username: req.user, review });
  res.json({ message: 'Review added/updated' });
};

exports.deleteReview = (req, res) => {
  const isbn = req.params.isbn;
  if (reviews[isbn]) {
    reviews[isbn] = reviews[isbn].filter(r => r.username !== req.user);
  }
  res.json({ message: 'Review deleted' });
};