const axios = require('axios');

const getAllBooks = async () => {
  const res = await axios.get('http://localhost:3000/books');
  console.log(res.data);
};

const searchByISBN = () => {
  return axios.get('http://localhost:3000/books/isbn/1234567890')
    .then(res => console.log(res.data))
    .catch(err => console.error(err));
};

const searchByAuthor = async () => {
  try {
    const res = await axios.get('http://localhost:3000/books/author/John');
    console.log(res.data);
  } catch (err) {
    console.error(err);
  }
};

const searchByTitle = async () => {
  try {
    const res = await axios.get('http://localhost:3000/books/title/Node');
    console.log(res.data);
  } catch (err) {
    console.error(err);
  }
};

module.exports = { getAllBooks, searchByISBN, searchByAuthor, searchByTitle };